import { Component, OnInit } from '@angular/core';
import { PhoneNotebookService } from './phoneNotebook.service';
import {Observable} from 'rxjs';

@Component({
  selector: 'app-phone-notebook',
  templateUrl: './phone-notebook.component.html',
  styleUrls: ['./phone-notebook.component.scss']
})
export class PhoneNotebookComponent implements OnInit{

 columnDefs = [
       { field: 'Id', sortable: true, filter: false },
       { field: 'Name', sortable: true, filter: true },
       { field: 'Phone', sortable: false, filter: true }
   ];

   rowData;
  

  constructor(private _phoneService : PhoneNotebookService) { 
  }

 ngOnInit(){
  this.getDataFromAPI();
 }

  getDataFromAPI(){
   this._phoneService.getPhoneListFromDb().subscribe((response)=>{
     console.log('Get Data Successfully');
    this.rowData=response;
   },
   (error)=>{
      console.log('Error is '+ error);
   }
  )
  }
  
}
